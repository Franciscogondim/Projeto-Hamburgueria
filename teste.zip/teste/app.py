from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/resposta", methods=["POST"])
def resposta():
    escolha = request.json["escolha"]

    if escolha == "hamburguer":
        return jsonify({
            "mensagem": "Qual hambúrguer você quer?",
            "opcoes": ["X-Burguer", "X-Salada"]
        })

    elif escolha == "bebida":
        return jsonify({
            "mensagem": "Qual bebida você quer?",
            "opcoes": ["Coca-Cola", "Suco"]
        })

    elif escolha == "X-Burguer":
        return jsonify({
            "mensagem": "Você escolheu X-Burguer 🍔"
        })

    elif escolha == "Coca-Cola":
        return jsonify({
            "mensagem": "Você escolheu Coca-Cola 🥤"
        })

    return jsonify({
        "mensagem": "Opção não encontrada"
    })

if __name__ == "__main__":
    app.run(debug=True)